#include "src/surpress_warnings_begin.h"
#if HISE_INCLUDE_RLOTTIE
#include "src/vector/freetype/v_ft_raster.cpp"
#endif
#include "src/surpress_warnings_end.h"


