#include "src/surpress_warnings_begin.h"
#if HISE_INCLUDE_RLOTTIE
#include "src/vector/stb/stb_image.cpp"
#endif
#include "src/surpress_warnings_end.h"


